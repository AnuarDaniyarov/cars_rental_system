package org.example.car_rental;

public class RentalSystem {
}
